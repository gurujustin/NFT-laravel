<?php $__env->startSection('contents'); ?>
<!-- home -->
<section id="home" class="home" data-src="img/home/slide.jpg" data-parallax>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="home__content">
                    <h1 class="home__title">Ucosmomasks Found</h1>

                    <p class="home__text">Secure & Easy Way To Buy NFTs</p>

                    <div class="home__btns">
                        <a data-scroll href="#token" class="home__btn home__btn--white"><span>Get Started</span></a>

                        <a href="#explore" class="home__btn"><span>Explore</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end home -->

<!-- about -->
<section id="about" class="about about--arrow section--gradient">
    <div class="container">
        <div class="row">
            <!-- section title -->
            <div class="col-12">
                <h2 class="section__title section__title--white section__title--margin">About Us</h2>
            </div>
            <!-- end section title -->

            <div class="col-12">
                <!-- about text -->
                <div class="about__text">
                    <p><b>Ucosmomasks Fund</b> is an NFT crypto art private fund that manages a collection of crypto art (NFT).</p>
                    <p>It was build to give the client  the opportunity to become a part of the company through the purchase of a uCMask token, the cost of which depends on the number of NFTs in the fund's asset and their nominal market value.</p>
                </div>
                <!-- end about text -->
            </div>
        </div>
    </div>
</section>
<!-- end about -->

<iframe id="explore"
src='https://opensea.io/assets?search%5Bquery%5D=Cosmomasks&search%5BsortAscending%5D=true&search%5BsortBy%5D=PRICE&embed=true'
width='100%'
height='100%'
frameborder='0'
allowfullscreen></iframe>

<!-- get started -->
<section class="section section--grey" id="token">
    <div class="container">
        <div class="row">
            <!-- section title -->
            <div class="col-12">
                <h2 class="section__title">How to Gget Started</h2>
                <span class="section__tagline">Your tagline</span>
            </div>
            <!-- end section title -->

            <div class="col-12 col-lg-4">
                <!-- box (style 6) -->
                <div class="box6">
                    <span class="box6__number">01</span>
                    <h3 class="box6__title">Go to DEX</h3>
                    <p class="box6__text">You can buy our token in <b>pancakeswap</b> or <b>uniswap</b>.</p>
                </div>
                <!-- end box (style 6) -->
            </div>

            <div class="col-12 col-lg-4">
                <!-- box (style 6) -->
                <div class="box6">
                    <span class="box6__number">02</span>
                    <h3 class="box6__title">Connect your Wallet</h3>
                    <p class="box6__text">you can connect your metamask or other wallet.</p>
                </div>
                <!-- end box (style 6) -->
            </div>

            <div class="col-12 col-lg-4">
                <!-- box (style 6) -->
                <div class="box6">
                    <span class="box6__number">03</span>
                    <h3 class="box6__title">Buy our Token</h3>
                    <p class="box6__text">You can buy <b>uCMask</b> Token and become a port of our company.</p>
                </div>
                <!-- end box (style 6) -->
            </div>

            <!-- section button -->
            <div class="col-12">
                <a href="https://exchange.pancakeswap.finance/#/swap" class="section__btn" target="__blank"><span>Go to DEX</span></a>
            </div>
            <!-- end section button -->
        </div>
    </div>
</section>
<!-- end get started -->


<!-- get in touch -->
<section id="contacts" class="section">
    <div class="container">
        <div class="row">
            <!-- section title -->
            <div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 col-xl-6 offset-xl-3">
                <h2 class="section__title">Get in Touch</h2>
                <p class="section__text">We are always open and we welcome and questions you have for our team. If you wish to get in touch, please fill out the form below.</p>
            </div>
            <!-- end section title -->

            <div class="col-12 col-md-6">
                <!-- contacts -->
                <div class="contacts">
                    <ul class="contacts__list">
                        <li>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18,4.48a8.45,8.45,0,0,0-12,12l5.27,5.28a1,1,0,0,0,1.42,0L18,16.43A8.45,8.45,0,0,0,18,4.48ZM16.57,15,12,19.59,7.43,15a6.46,6.46,0,1,1,9.14,0ZM9,7.41a4.32,4.32,0,0,0,0,6.1,4.31,4.31,0,0,0,7.36-3,4.24,4.24,0,0,0-1.26-3.05A4.3,4.3,0,0,0,9,7.41Zm4.69,4.68a2.33,2.33,0,1,1,.67-1.63A2.33,2.33,0,0,1,13.64,12.09Z"/></svg>
                            </span>
                            <p>The BuyCoin Company, LLC <br>
                            32 Barnard St. #145, GA 80634</p>
                        </li>
                        <li>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,2A10,10,0,1,0,22,12,10.01114,10.01114,0,0,0,12,2Zm0,18a8,8,0,1,1,8-8A8.00917,8.00917,0,0,1,12,20ZM14.09814,9.63379,13,10.26807V7a1,1,0,0,0-2,0v5a1.00025,1.00025,0,0,0,1.5.86621l2.59814-1.5a1.00016,1.00016,0,1,0-1-1.73242Z"/></svg>
                            </span>
                            <p>Mon - Fri: <br>08:00 - 19:00</p>
                        </li>
                        <li>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19,4H5A3,3,0,0,0,2,7V17a3,3,0,0,0,3,3H19a3,3,0,0,0,3-3V7A3,3,0,0,0,19,4Zm-.41,2-5.88,5.88a1,1,0,0,1-1.42,0L5.41,6ZM20,17a1,1,0,0,1-1,1H5a1,1,0,0,1-1-1V7.41l5.88,5.88a3,3,0,0,0,4.24,0L20,7.41Z"/></svg>
                            </span>
                            <a href="mailto:ucosmomasks.info@gmail.com">ucosmomasks.info@gmail.com</a>
                        </li>
                        <li>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12.71,16.29l-.15-.12a.76.76,0,0,0-.18-.09L12.2,16a1,1,0,0,0-.91.27,1.15,1.15,0,0,0-.21.33,1,1,0,0,0,1.3,1.31,1.46,1.46,0,0,0,.33-.22,1,1,0,0,0,.21-1.09A1,1,0,0,0,12.71,16.29ZM16,2H8A3,3,0,0,0,5,5V19a3,3,0,0,0,3,3h8a3,3,0,0,0,3-3V5A3,3,0,0,0,16,2Zm1,17a1,1,0,0,1-1,1H8a1,1,0,0,1-1-1V5A1,1,0,0,1,8,4h8a1,1,0,0,1,1,1Z"/></svg>
                            </span>
                            <a href="tel:88002345678">8 800 234-56-78</a>
                        </li>
                    </ul>
                </div>
                <!-- end contacts -->
            </div>

            <div class="col-12 col-md-6">
                <!-- form -->
                <form action="#" class="form form--contacts">
                    <input type="text" class="form__input" placeholder="Name">
                    <input type="text" class="form__input" placeholder="Email">
                    <textarea class="form__textarea" placeholder="Message"></textarea>
                    <button class="form__btn" type="button"><span>Send</span></button>
                </form>
                <!-- end form -->
            </div>
        </div>
    </div>
</section>
<!-- end get in touch -->

<!-- privacy -->
<div id="privacy" class="zoom-anim-dialog mfp-hide modal modal--article">
    <button class="modal__close" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13.41,12l4.3-4.29a1,1,0,1,0-1.42-1.42L12,10.59,7.71,6.29A1,1,0,0,0,6.29,7.71L10.59,12l-4.3,4.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l4.29,4.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z"></path></svg></button>

    <div class="modal__article">
        <h1>Privacy policy</h1>

        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>

        <h4>Determination of personal information of users</h4>

        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.</p>

        <ol>
            <li>If you are going to use a passage of Lorem Ipsum:
                <ol>
                    <li>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</li>
                    <li>It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</li>
                </ol>
            </li>
            <li>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</li>
            <li>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</li>
        </ol>

        <h4>Reasons for collecting and processing user personal information</h4>

        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>

        <ol>
            <li>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>
            <li>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet:
                <ol>
                    <li>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged;</li>
                    <li>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages;</li>
                    <li>Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like);</li>
                    <li>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text;</li>
                </ol>
            </li>
        </ol>

        <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>

        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. <a href="#">Link</a> the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
    </div>
</div>
<!-- end privacy -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software_works\blockchain\nft-gallery\resources\views/welcome.blade.php ENDPATH**/ ?>